<?php
$servername = "localhost";
$username = "root";
$password = ""; // O tu contraseña si configuraste una
$dbname = "legumbre"; // Asegúrate de que sea el nombre correcto de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
