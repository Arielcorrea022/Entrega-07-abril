<?php
include 'db_conecct.php'; // Conecta con la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $conn->real_escape_string($_POST['usuario']);
    $clave = password_hash($_POST['clave'], PASSWORD_DEFAULT); // Cifra la contraseña

    // Verifica si el usuario ya existe
    $query_check = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $result = $conn->query($query_check);

    if ($result && $result->num_rows > 0) {
        echo "<p>El usuario ya existe. Intenta con otro nombre.</p>";
        echo "<a href='register.php'>Volver al registro</a>";
    } else {
        // Inserta el nuevo usuario
        $query_insert = "INSERT INTO usuarios (usuario, clave, rol) VALUES ('$usuario', '$clave', 'Cliente')";
        if ($conn->query($query_insert)) {
            echo "<p>Registro exitoso. ¡Ya puedes iniciar sesión!</p>";
            echo "<a href='index.html'>Ir al Login</a>";
        } else {
            echo "<p>Error al registrar el usuario: " . $conn->error . "</p>";
        }
    }
}
?>
