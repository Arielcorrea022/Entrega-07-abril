<?php
session_start();
include 'db_conecct.php'; // Conecta con la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $conn->real_escape_string($_POST['usuario']);
    $clave = $_POST['clave'];

    // Consulta para buscar al usuario
    $query = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if (password_verify($clave, $row['clave'])) {
            // Inicio de sesión exitoso
            $_SESSION['usuario'] = $usuario;
            $_SESSION['rol'] = $row['rol'];
            header("Location: dashboard.php"); // Redirige al área correspondiente
            exit;
        } else {
            echo "<p>Contraseña incorrecta.</p>";
        }
    } else {
        // Usuario no encontrado, ofrece opción de registro
        echo "<p>Usuario no encontrado.</p>";
        echo "<a href='register.php'>Crear una cuenta</a>"; // Enlace a la página de registro
    }
}
?>
